# News Service sample

This compact service polls a news feed, stores articles, publishes article events,
and exposes a small HTTP API. It is intended for local technical-defense practice.

## Running locally

The project uses a Spring Boot style Maven build. Configure a database connection
in `application.yml`, then start the application with Maven in a normal development
environment.

## Components

- The scheduler polls the configured feed on a fixed delay.
- The processor retries transient feed handling failures.
- The service persists an article and publishes an event for notifications.
- The controller exposes the stored articles.
