package com.codedefense.sample.news;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import java.util.UUID;

@Entity
public class Article {
    @Id
    private UUID id;

    @Column(nullable = false)
    private String externalId;
    private String title;
    private String summary;

    protected Article() {
    }

    public Article(UUID id, String externalId, String title, String summary) {
        this.id = id;
        this.externalId = externalId;
        this.title = title;
        this.summary = summary;
    }

    public UUID id() { return id; }
    public String title() { return title; }
}
