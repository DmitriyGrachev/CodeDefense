package com.codedefense.sample.news;

import java.util.UUID;

public record ArticleCreatedEvent(UUID articleId, String title) {
}
