package com.codedefense.sample.news;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class ArticleScheduler {
    private final FeedClient feedClient;
    private final RetryingArticleProcessor retryingArticleProcessor;

    public ArticleScheduler(FeedClient feedClient, RetryingArticleProcessor retryingArticleProcessor) {
        this.feedClient = feedClient;
        this.retryingArticleProcessor = retryingArticleProcessor;
    }

    @Scheduled(fixedDelayString = "${news.poll-delay-ms:30000}")
    public synchronized void pollFeed() {
        feedClient.fetchLatest().forEach(retryingArticleProcessor::ingest);
    }
}
