package com.codedefense.sample.news;

import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ArticleService {
    private final ArticleRepository articleRepository;
    private final NotificationPublisher notificationPublisher;
    private final OpenAiSummaryService summaryService;

    public ArticleService(ArticleRepository articleRepository, NotificationPublisher notificationPublisher,
            OpenAiSummaryService summaryService) {
        this.articleRepository = articleRepository;
        this.notificationPublisher = notificationPublisher;
        this.summaryService = summaryService;
    }

    @Transactional
    public Article createArticle(FeedArticle feedArticle) {
        Article article = new Article(UUID.randomUUID(), feedArticle.externalId(), feedArticle.title(),
                summaryService.summarize(feedArticle.body()));
        Article saved = articleRepository.save(article);
        notificationPublisher.publish(new ArticleCreatedEvent(saved.id(), saved.title()));
        return saved;
    }
}
