package com.codedefense.sample.news;

public record FeedArticle(String externalId, String title, String body) {
}
