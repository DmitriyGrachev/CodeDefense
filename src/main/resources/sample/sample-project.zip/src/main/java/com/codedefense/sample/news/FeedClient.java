package com.codedefense.sample.news;

import java.util.List;
import org.springframework.stereotype.Component;

@Component
public class FeedClient {
    public List<FeedArticle> fetchLatest() {
        return List.of();
    }
}
