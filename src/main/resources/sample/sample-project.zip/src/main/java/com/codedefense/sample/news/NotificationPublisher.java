package com.codedefense.sample.news;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

@Component
public class NotificationPublisher {
    private final ApplicationEventPublisher events;

    public NotificationPublisher(ApplicationEventPublisher events) {
        this.events = events;
    }

    public void publish(ArticleCreatedEvent event) {
        events.publishEvent(event);
    }
}
