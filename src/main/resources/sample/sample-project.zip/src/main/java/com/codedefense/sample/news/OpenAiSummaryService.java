package com.codedefense.sample.news;

import org.springframework.stereotype.Service;

@Service
public class OpenAiSummaryService {
    public String summarize(String body) {
        return body.length() > 160 ? body.substring(0, 160) : body;
    }
}
