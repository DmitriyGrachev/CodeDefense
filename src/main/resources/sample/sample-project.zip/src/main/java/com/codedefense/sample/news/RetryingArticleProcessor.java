package com.codedefense.sample.news;

import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

@Component
public class RetryingArticleProcessor {
    private final ArticleService articleService;

    public RetryingArticleProcessor(ArticleService articleService) {
        this.articleService = articleService;
    }

    @Retryable(backoff = @Backoff(delay = 500))
    public void ingest(FeedArticle feedArticle) {
        articleService.createArticle(feedArticle);
    }
}
